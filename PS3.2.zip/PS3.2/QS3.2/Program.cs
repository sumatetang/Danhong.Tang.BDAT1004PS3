﻿using System;
using System.Collections.Generic;
using System.Linq;
using Console = System.Console;


// For Problem Set 3 Question 2
namespace QS3._2
{
    class Program
    {
        static void Main(string[] args)
        {
            // Input n & m, and validate.
            int n = 0, m = 0;
            do
            {
                try
                {
                    Console.Write("Please enter two space-separated integers, n and m: ");
                    var nm = Console.ReadLine()
                        ?.Split(" ")
                        .Select(int.Parse)
                        .ToArray();
                    if (nm.Count() != 2)
                        continue;

                    n = nm[0];
                    if (n < 1 || n > 10)
                    {
                        Console.WriteLine("n should greater or equal than 1 and less or equal than 10");
                        continue;
                    }

                    m = nm[1];
                    if (m < 1 || m > 10)
                    {
                        Console.WriteLine("m should greater or equal than 1 and less or equal than 10");
                        continue;
                    }

                    break;
                }
                catch (Exception)
                {
                    // ignored
                }
            } while (true);

            var a = EnterArray(n, "a");
            var b = EnterArray(m, "b");

            var result = getTotalX(a, b);
            Console.WriteLine(result);
        }

        private static int[] EnterArray(int count, string name)
        {
            do
            {
                try
                {
                    Console.Write(
                        $"Please enter {name} as {count} distinct space-separated integers describing {name}[i] where 1 <= i <= 100: ");
                    var result = Console.ReadLine()
                        ?.Split(" ")
                        .Select(int.Parse)
                        .ToArray();
                    if (result.Count() != count)
                    {
                        Console.WriteLine($"Expected number count is {count} while you have inputted {result.Count()} numbers.");
                        continue;
                    }

                    if (result.All(element => element >= 1 && element <= 100))
                    {
                        return result;
                    }
                }
                catch (Exception)
                {
                    // ignored
                }
            } while (true);
        }

        /// <summary>
        /// Return the number of integers that are between the sets.
        /// </summary>
        /// <param name="a">an array of integers</param>
        /// <param name="b">an array of integers</param>
        /// <returns>The number of integers that are between the sets.</returns>
        static int getTotalX(int[] a, int[] b)
        {
            var resultList = new List<int>();

            // To avoid redundant calculate.
            var maxA = a.Max();
            var minB = b.Min();

            for (int i = 1; ; i++)
            {
                var candidate = maxA * i;
                if (candidate > minB)
                {
                    break;
                }

                if (a.All(element => candidate % element == 0) &&
                    b.All(element => element % candidate == 0))
                {
                    resultList.Add(candidate);
                }
            }

            //Console.WriteLine(string.Join(" ", resultList));
            return resultList.Count;
        }
    }
}
