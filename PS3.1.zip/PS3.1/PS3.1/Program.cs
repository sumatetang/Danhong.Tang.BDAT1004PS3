﻿

using System;
using System.Linq;


// For Problem Set 3 Question 1
namespace PS3._1
{
    internal class Program
    {
        private static void Main(string[] args)
        {
            //Test code
            //Console.WriteLine(angryProfessor(3, new[] {0, 0, 5}));
            //return;

            bool isSuccess = false;
            int t, n = 0, k = 0;
            int[] a = null;
            do
            {
                Console.Write("Please input the number of test cases: ");
                var readT = Console.ReadLine();
                isSuccess = int.TryParse(readT, out t);
                if (!isSuccess) continue;

                isSuccess = t >= 1 && t <= 10;
            } while (!isSuccess);

            for (int testCase = 0; testCase < t; testCase++)
            {
                do
                {
                    Console.Write("Please input the number of students & the cancellation threshold: ");
                    var readNK = Console.ReadLine();
                    var nk = readNK.Split(" ");

                    isSuccess = nk.Length == 2;
                    if (!isSuccess) continue;

                    isSuccess = int.TryParse(nk[0], out n);
                    if (!isSuccess) continue;

                    isSuccess = n >= 1 && n <= 1000;
                    if (!isSuccess) continue;

                    isSuccess = int.TryParse(nk[1], out k);
                    if (!isSuccess) continue;

                    isSuccess = k >= 1 && k <= n;
                    if (!isSuccess) continue;
                } while (!isSuccess);

                do
                {
                    try
                    {
                        Console.Write("Please input the arrival times for each student: ");
                        var readA = Console.ReadLine();
                        a = readA.Split(" ").Select(aString => int.Parse(aString)).ToArray();
                        isSuccess = true;

                        if (a.Length != n)
                        {
                            isSuccess = false;
                            continue;
                        }

                        isSuccess = a.All(arriveTime => arriveTime >= -100 && arriveTime <= 100);
                    }
                    catch (Exception e)
                    {
                        isSuccess = false;
                    }
                } while (!isSuccess);

                // All input data are ready.
                Console.WriteLine(angryProfessor(k, a));
            }
        }

        /// <summary>
        ///     A Data Programming professor has a class of students. Frustrated with their lack of discipline, he decides to
        ///     cancel class if fewer than some number of students are present when class starts Arrival times go from on
        ///     time(𝑎𝑟𝑟𝑖𝑣𝑎𝑙𝑇𝑖𝑚𝑒 ≤ 0) to arrived late(𝑎𝑟𝑟𝑖𝑣𝑎𝑙𝑇𝑖𝑚𝑒 > 0).
        /// </summary>
        /// <param name="k">the threshold number of students</param>
        /// <param name="a">an array of integers representing arrival times</param>
        /// <returns>"YES" if class is canceled, "NO" otherwise</returns>
        private static string angryProfessor(int k, int[] a)
        {
            return a.Count(arriveTime => arriveTime <= 0) < k ? "YES" : "NO";
        }
    }
}